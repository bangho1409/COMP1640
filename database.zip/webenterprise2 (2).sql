-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2022 at 08:34 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webenterprise2`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id_category` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `tag` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `close_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id_category`, `name`, `tag`, `description`, `close_date`) VALUES
(1, 'Feedback about parking lot places and price', '#parking #feedback', 'Gather information of student, teacher, and staff about parking lot issues', '2014-04-04'),
(2, 'Choosing main content for the next event (Summer Party)', '#event #voting', 'Choosing content for next event:\r\nA- Clubs day\r\nB- Books exhibition\r\nC- Workshops \r\nD- ... Other ideas', '0000-00-00'),
(3, 'Feedback about new library', '#feedback #library ', 'Gathering information from staffs, student about new library', '0000-00-00'),
(4, 'Notification about incoming tests', '#test #exam #schedule', 'Incoming test and exam schedule, participants, places, ...', '2026-04-11'),
(18, 'TESTING CATEGORY', '#TESTTAG', 'THIS IS FOR TESTING', '2022-04-30'),
(20, 'IDEAZ Demo', '#Ideazdemo', 'This is a demonstration', '2022-04-28'),
(21, 'Ideaznewdemo', '#InterestingDemo', 'This is an interesting category', '2022-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id_comment` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_date` datetime NOT NULL,
  `last_modified_date` datetime NOT NULL,
  `username` varchar(50) NOT NULL,
  `id_idea` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id_comment`, `content`, `created_date`, `last_modified_date`, `username`, `id_idea`) VALUES
(41, 'good idea', '2022-04-24 19:44:10', '2022-04-24 19:44:10', 'admin', 10),
(42, 'nicely done', '2022-04-24 20:22:05', '2022-04-24 20:22:05', 'admin', 10),
(43, 'very interesting', '2022-04-24 20:58:15', '2022-04-24 20:58:15', 'admin', 10),
(44, 'very informative', '2022-04-24 21:10:55', '2022-04-24 21:10:55', 'admin', 10),
(45, 'Im impressed', '2022-04-24 21:14:40', '2022-04-24 21:14:40', 'user', 10),
(46, 'nice idea', '2022-04-24 21:16:54', '2022-04-24 21:16:54', 'user', 12);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id_department` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id_department`, `name`) VALUES
(1, 'Office of Student Affairs'),
(2, 'Office of Academic Department'),
(3, 'IT Applications and Websites'),
(4, 'Administrative Affairs'),
(5, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE `file` (
  `id_file` int(11) NOT NULL,
  `file_path` varbinary(255) NOT NULL,
  `last_modified_date` datetime NOT NULL,
  `id_idea` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `file`
--

INSERT INTO `file` (`id_file`, `file_path`, `last_modified_date`, `id_idea`) VALUES
(1, 0x31313638312d696e6465782e7a6970, '2022-04-20 22:24:29', 2),
(2, 0x39303738372d696e6465782e7a6970, '2022-04-21 17:15:47', 4),
(3, 0x32363930332d746f7069632d73656c656374696f6e2e7a6970, '2022-04-24 21:16:01', 11);

-- --------------------------------------------------------

--
-- Table structure for table `idea`
--

CREATE TABLE `idea` (
  `id_idea` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_date` datetime NOT NULL,
  `last_modified_date` datetime NOT NULL,
  `username` varchar(255) NOT NULL,
  `id_category` int(11) NOT NULL,
  `view` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `idea`
--

INSERT INTO `idea` (`id_idea`, `title`, `content`, `created_date`, `last_modified_date`, `username`, `id_category`, `view`) VALUES
(10, 'Demo idea', 'demonstration', '2022-04-21 23:20:51', '2022-04-24 14:38:51', 'admin', 18, 98),
(11, 'Test Idea', ' Idea Test', '2022-04-22 00:34:43', '2022-04-22 00:34:43', 'admin', 18, 2),
(12, 'This is amazing', 'The school is amazing', '2022-04-24 21:15:54', '2022-04-24 21:15:54', 'user', 21, 2);

-- --------------------------------------------------------

--
-- Table structure for table `reaction`
--

CREATE TABLE `reaction` (
  `id_idea` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `reaction` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reaction`
--

INSERT INTO `reaction` (`id_idea`, `id_user`, `reaction`) VALUES
(10, 1, 'like'),
(11, 1, 'like');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id_role` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id_role`, `name`) VALUES
(1, 'QA Manager'),
(2, 'QA Coordinator '),
(3, 'Student'),
(4, 'Teacher'),
(5, 'Staffs'),
(6, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `id_role` int(11) NOT NULL,
  `id_department` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `email`, `password`, `id_role`, `id_department`) VALUES
(1, 'admin', '', '12345', 6, 2),
(2, 'qamanager', 'qacousay123@gmail.com', '12345', 1, 0),
(3, 'user', 'receivercousay123@gmail.com', '12345', 3, 5),
(4, 'staff', 'receivercousay123@gmail.com', '12345', 4, 2),
(5, 'huubang', 'bangho1409@gmail.com', '12345', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `view`
--

CREATE TABLE `view` (
  `id_view` int(11) NOT NULL,
  `last_visited_date` datetime NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_idea` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id_category`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id_comment`),
  ADD KEY `id_idea` (`id_idea`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id_department`);

--
-- Indexes for table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`id_file`),
  ADD KEY `id_idea` (`id_idea`);

--
-- Indexes for table `idea`
--
ALTER TABLE `idea`
  ADD PRIMARY KEY (`id_idea`),
  ADD KEY `id_user` (`username`),
  ADD KEY `id_category` (`id_category`);

--
-- Indexes for table `reaction`
--
ALTER TABLE `reaction`
  ADD UNIQUE KEY `id_idea` (`id_idea`,`id_user`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id_role`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_role` (`id_role`),
  ADD KEY `id_department` (`id_department`);

--
-- Indexes for table `view`
--
ALTER TABLE `view`
  ADD PRIMARY KEY (`id_view`),
  ADD KEY `id_idea` (`id_idea`),
  ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id_department` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `file`
--
ALTER TABLE `file`
  MODIFY `id_file` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `idea`
--
ALTER TABLE `idea`
  MODIFY `id_idea` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `view`
--
ALTER TABLE `view`
  MODIFY `id_view` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
